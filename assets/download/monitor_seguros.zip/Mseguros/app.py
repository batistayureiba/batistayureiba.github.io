import streamlit as st
import duckdb
import os
import re
from dotenv import load_dotenv

# 1. CONFIGURACIÓN E INTERFAZ
st.set_page_config(page_title="Monitor de Seguros Pro", page_icon="📊", layout="wide")
load_dotenv()

@st.cache_resource
def get_connection():
    token = os.getenv('MOTHERDUCK_TOKEN')
    return duckdb.connect(f'md:my_db?motherduck_token={token}')

con = get_connection()

def limpiar_nombre_aseguradora(texto):
    if not texto: return texto
    paso1 = re.sub(r'^[\d\s\-]+', '', str(texto))
    return paso1.replace('"', '').strip()

if 'reset_key' not in st.session_state:
    st.session_state.reset_key = 0

def ejecutar_reset():
    st.session_state.reset_key += 1
    st.rerun()

# 2. SIDEBAR CON FILTROS
st.sidebar.header("🛠️ Selección de Vehículo")

df_marcas = con.execute("SELECT DISTINCT marca FROM fasecolda_catalogo WHERE marca IS NOT NULL ORDER BY marca").df()
marca_sel = st.sidebar.selectbox("1. Marca", options=df_marcas['marca'], index=None, placeholder="Marca...", key=f"m_{st.session_state.reset_key}")

clase_sel = None
if marca_sel:
    df_clases = con.execute(f"SELECT DISTINCT clase FROM fasecolda_catalogo WHERE marca = '{marca_sel}' AND clase IS NOT NULL ORDER BY clase").df()
    clase_sel = st.sidebar.selectbox("2. Clase", options=df_clases['clase'], index=None, placeholder="Clase...", key=f"c_{st.session_state.reset_key}")

ref_sel = None
if clase_sel:
    df_refs = con.execute(f"SELECT DISTINCT referencia1 FROM fasecolda_catalogo WHERE marca = '{marca_sel}' AND clase = '{clase_sel}' ORDER BY referencia1").df()
    ref_sel = st.sidebar.selectbox("3. Referencia", options=df_refs['referencia1'], index=None, placeholder="Modelo...", key=f"r_{st.session_state.reset_key}")

anio_sel = None
if ref_sel:
    temp_df = con.execute(f"SELECT * FROM fasecolda_catalogo LIMIT 1").df()
    anios_disponibles = sorted([c for c in temp_df.columns if c.startswith('20')], reverse=True)
    anio_sel = st.sidebar.selectbox("4. Año del Modelo", options=anios_disponibles, key=f"a_{st.session_state.reset_key}")

st.sidebar.divider()
if st.sidebar.button("🔄 Limpiar Filtros", use_container_width=True):
    ejecutar_reset()

# 3. HEADER CENTRAL
st.markdown("<h1 style='text-align: center;'>📊 Monitor Inteligente de Seguros</h1>", unsafe_allow_html=True)
st.write("") 

if marca_sel and clase_sel and ref_sel and anio_sel:
    # --- VISTA DE RESULTADOS ---
    info_carro = con.execute(f"SELECT * FROM fasecolda_catalogo WHERE marca = '{marca_sel}' AND clase = '{clase_sel}' AND referencia1 = '{ref_sel}' LIMIT 1").df()
    df_ranking = con.execute("SELECT * FROM market_ranking ORDER BY market_share DESC").df()
    df_ranking['Aseguradora'] = df_ranking['nombre_entidad'].apply(limpiar_nombre_aseguradora)
    df_ranking['Nivel de Respaldo'] = df_ranking['market_share'].apply(lambda x: "🟢 Muy Alto" if x > 15 else ("🟡 Alto" if x > 5 else "⚪ Medio"))

    col1, col2 = st.columns([1, 1], gap="large")

    with col1:
        st.subheader("📋 Ficha Técnica")
        if not info_carro.empty:
            cols_tecnicas = [c for c in info_carro.columns if not c.startswith('20')]
            ficha = info_carro[cols_tecnicas].T
            ficha.columns = ["Detalle"]
            ficha = ficha[(ficha["Detalle"] != 0) & (ficha["Detalle"] != "") & (ficha["Detalle"].notna())]
            st.table(ficha)

    with col2:
        st.subheader("💡 Análisis de Respaldo")
        valor_anio = info_carro[anio_sel].iloc[0]
        st.metric(label=f"Valor Asegurado ({anio_sel})", value=f"${valor_anio:,.0f} COP")

        st.write("---")
        st.write("### Solidez de Aseguradoras")
        st.dataframe(
            df_ranking.head(5)[['Aseguradora', 'Nivel de Respaldo', 'market_share']], 
            column_config={"market_share": st.column_config.ProgressColumn("Participación", format="%.2f%%", min_value=0, max_value=25)},
            hide_index=True, use_container_width=True
        )
        
        # Gráfico con etiqueta corregida
        df_grafico = df_ranking.head(5).rename(columns={'market_share': 'Nivel de Respaldo (%)'})
        st.bar_chart(df_grafico, x='Aseguradora', y='Nivel de Respaldo (%)', color="#074d91")

    # 4. INTELIGENCIA DE MERCADO
    st.divider()
    st.subheader("📈 Inteligencia de Negocio")
    m1, m2, m3 = st.columns(3)
    
    with m1:
        st.info(f"**Liderazgo**\n\n{df_ranking.iloc[0]['Aseguradora']} lidera con el {df_ranking.iloc[0]['market_share']:.2f}% del mercado.")
    with m2:
        st.success(f"**Respaldo Sectorial**\n\nEl Top 5 de aseguradoras concentra la mayor capacidad de respuesta del país.")
    with m3:
        st.warning(f"**Recomendación**\n\nPara un {marca_sel}, prioriza entidades con nivel de respaldo 🟢 o 🟡.")

else:
    # --- VISTA HOME (ESTADO INICIAL) ---
    col_a, col_b = st.columns([2, 1])
    with col_a:
        st.markdown("""
        ### Bienvenido al Monitor de Seguros
        Plataforma analítica para la evaluación de solvencia y valores comerciales del sector automotriz.
        
        **Acciones Disponibles:**
        * **Consultar Valores:** Acceso a la base de datos de Fasecolda 2026.
        * **Ranking de Solidez:** Comparativa de aseguradoras por cuota de mercado.
        * **Análisis de Riesgo:** Información basada en reportes de la Superfinanciera.
        """)
    with col_b:
        st.info("👈 Selecciona los datos del vehículo para generar el reporte.")

    st.write("---")
    st.subheader("Panorama General: Top 10 Aseguradoras (Automóviles)")
    df_gen = con.execute("SELECT nombre_entidad, market_share FROM market_ranking ORDER BY market_share DESC LIMIT 10").df()
    df_gen['Aseguradora'] = df_gen['nombre_entidad'].apply(limpiar_nombre_aseguradora)
    
    # Gráfico del Home con etiqueta corregida
    df_gen = df_gen.rename(columns={'market_share': 'Nivel de Respaldo (%)'})
    st.bar_chart(df_gen, x='Aseguradora', y='Nivel de Respaldo (%)', color="#074d91")

st.write("")
st.caption("Fuente: Datos Abiertos Colombia (SFC) | Guía de Valores Fasecolda | Proyecto Mseguros 2026")