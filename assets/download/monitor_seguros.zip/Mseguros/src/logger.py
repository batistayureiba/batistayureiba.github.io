import logging
import os

def setup_logger():
    # Crear carpeta de logs si no existe
    if not os.path.exists('logs'):
        os.makedirs('logs')
    
    logger = logging.getLogger('MonitorSeguros')
    logger.setLevel(logging.INFO)
    
    # Formato profesional: Fecha - Nivel - Mensaje
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    
    # Handler para archivo
    file_handler = logging.FileHandler('logs/monitor.log')
    file_handler.setFormatter(formatter)
    
    # Handler para consola (para que veas el progreso)
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    
    if not logger.handlers:
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
    
    return logger