import duckdb
import os
from src.logger import setup_logger
from dotenv import load_dotenv

load_dotenv()
logger = setup_logger()

class MotherDuckManager:
    def __init__(self):
        self.token = os.getenv('MOTHERDUCK_TOKEN')
        self.con = None

    def connect(self):
        try:
            # Conexión a MotherDuck usando el token del .env
            self.con = duckdb.connect(f'md:my_db?motherduck_token={self.token}')
            logger.info("Conexión exitosa a MotherDuck.")
        except Exception as e:
            logger.error(f"Error conectando a MotherDuck: {e}")
            raise

    def load_dataframe(self, df, table_name):
        """Carga un DataFrame de Pandas directamente a una tabla en la nube."""
        if self.con is None:
            self.connect()
        try:
            logger.info(f"Cargando datos en la tabla: {table_name}...")
            # DuckDB registra el DF local y lo sube a la nube
            self.con.register('df_tmp', df)
            self.con.execute(f"CREATE OR REPLACE TABLE {table_name} AS SELECT * FROM df_tmp")
            logger.info(f"Tabla {table_name} creada/actualizada exitosamente.")
        except Exception as e:
            logger.error(f"Error cargando datos a la tabla {table_name}: {e}")

    def close(self):
        if self.con:
            self.con.close()
            logger.info("Conexión a base de datos cerrada.")