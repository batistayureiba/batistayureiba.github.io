import pandas as pd
from src.logger import setup_logger

logger = setup_logger()

class DataTransformer:
    def __init__(self, df_seguros, df_fasecolda):
        self.df_seguros = df_seguros
        self.df_fasecolda = df_fasecolda

    def clean_and_prepare(self):
        """Lógica para limpiar y cruzar los dos mundos."""
        try:
            logger.info("Iniciando transformación y cruce de datos...")
            
            # 1. CONVERSIÓN NUMÉRICA (Crucial)
            # Convertimos 'automoviles' a número. 'coerce' pone NaN si hay basura y luego llenamos con 0.
            self.df_seguros['automoviles'] = pd.to_numeric(self.df_seguros['automoviles'], errors='coerce').fillna(0)
            
            # 2. Agrupar la data de la API por Aseguradora
            stats_aseguradoras = self.df_seguros.groupby('nombre_entidad')['automoviles'].sum().reset_index()
            
            # 3. Calcular % de participación de mercado (Market Share)
            total_mercado = stats_aseguradoras['automoviles'].sum()
            
            if total_mercado > 0:
                stats_aseguradoras['market_share'] = (stats_aseguradoras['automoviles'] / total_mercado) * 100
            else:
                stats_aseguradoras['market_share'] = 0
                
            stats_aseguradoras = stats_aseguradoras.sort_values(by='market_share', ascending=False)
            
            logger.info("Transformación completada con éxito.")
            # Retornamos los DataFrames listos para ser subidos
            return stats_aseguradoras, self.df_fasecolda
            
        except Exception as e:
            logger.error(f"Error en la transformación: {e}")
            return None, None