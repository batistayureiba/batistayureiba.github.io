import pandas as pd
import requests
import os
from src.logger import setup_logger

logger = setup_logger()

class DataExtractor:
    def __init__(self, api_url, local_path):
        self.api_url = api_url
        self.local_path = local_path

    def fetch_api_data(self, limit=50000):
        """Descarga dinámica de la API de Datos Abiertos."""
        try:
            logger.info(f"Iniciando descarga de API: {self.api_url}")
            full_url = f"{self.api_url}?$limit={limit}"
            response = requests.get(full_url, timeout=15)
            response.raise_for_status()
            df = pd.DataFrame(response.json())
            logger.info(f"API descargada exitosamente: {len(df)} registros.")
            return df
        except Exception as e:
            logger.error(f"Fallo en la extracción de API: {e}")
            return None

    def fetch_local_fasecolda(self):
        """Lectura de la segunda hoja del Excel de Fasecolda."""
        if not os.path.exists(self.local_path):
            logger.error(f"Archivo no encontrado en: {self.local_path}")
            return None
        
        try:
            logger.info(f"Leyendo datos de la segunda hoja de: {self.local_path}")
            # Seleccionamos hoja 2 (índice 1) donde están los autos
            df = pd.read_excel(self.local_path, sheet_name=1, header=0, engine='openpyxl')
            
            # Limpieza de nombres de columnas para DuckDB
            df.columns = [str(c).lower().strip().replace(" ", "_").replace(".", "") for c in df.columns]
            
            # Limpieza de filas vacías
            df = df.dropna(how='all')
            
            logger.info(f"Fasecolda cargado exitosamente. Registros: {len(df)}")
            return df
        except Exception as e:
            logger.error(f"Error procesando la data de autos en Fasecolda: {e}")
            return None