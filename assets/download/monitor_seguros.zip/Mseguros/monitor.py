import os
from dotenv import load_dotenv
from src.logger import setup_logger
from src.extractor import DataExtractor
from src.database import MotherDuckManager
from src.transformer import DataTransformer  # <--- Nuevo!

load_dotenv()
logger = setup_logger()

def main():
    logger.info("=== Iniciando Monitor de Seguros: Pipeline Pro ===")
    
    # 1. Configuración
    api_url = os.getenv('DATASET_URL')
    fasecolda_path = "data/fasecolda.xlsx"
    
    extractor = DataExtractor(api_url, fasecolda_path)
    db_manager = MotherDuckManager()
    
    # 2. Extracción
    df_api = extractor.fetch_api_data()
    df_fase = extractor.fetch_local_fasecolda()
    
    if df_api is not None and df_fase is not None:
        # 3. Transformación (Aquí es donde ocurre la magia del negocio)
        transformer = DataTransformer(df_api, df_fase)
        df_ranking, df_fase_clean = transformer.clean_and_prepare()
        
        # 4. Carga a MotherDuck
        try:
            db_manager.connect()
            # Guardamos la data limpia de autos
            db_manager.load_dataframe(df_fase_clean, "fasecolda_catalogo")
            # Guardamos el análisis de mercado de aseguradoras
            db_manager.load_dataframe(df_ranking, "market_ranking")
            
            logger.info("=== Pipeline finalizado. Datos listos para Streamlit ===")
        except Exception as e:
            logger.error(f"Error en carga: {e}")
        finally:
            db_manager.close()
    else:
        logger.error("Error crítico en la extracción.")

if __name__ == "__main__":
    main()