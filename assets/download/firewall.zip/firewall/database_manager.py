import sqlite3
import pandas as pd
import duckdb

def load_sql_to_dataframe(sql_file_path, table_name):
    conn = sqlite3.connect(':memory:')
    try:
        with open(sql_file_path, 'r', encoding='utf-8') as f:
            sql_script = f.read()
        conn.executescript(sql_script)
        return pd.read_sql_query(f"SELECT * FROM {table_name}", conn)
    finally:
        conn.close()

def save_to_duckdb_local(df, table_name, db_name="ecommerce_clean.duckdb"):
    conn = duckdb.connect(db_name)
    try:
        conn.execute(f"CREATE OR REPLACE TABLE {table_name} AS SELECT * FROM df")
    finally:
        conn.close()

def get_local_table_names(db_name="ecommerce_clean.duckdb"):
    con = duckdb.connect(db_name)
    # Extraemos el vector simple de nombres
    tablas = [fila[0] for fila in con.execute("SELECT table_name FROM information_schema.tables WHERE table_name NOT LIKE 'audit_%'").fetchall()]
    con.close()
    return tablas

def upload_to_motherduck(db_local, token):
    print("☁️  SYNCING TO CLOUD DATA WAREHOUSE.\n")
    try:
        md_conn = duckdb.connect(f"md:?motherduck_token={token}")
        md_conn.execute("CREATE DATABASE IF NOT EXISTS ecommerce_cloud")
        md_conn.execute(f"ATTACH '{db_local}' AS local_db")
        
        # Sincronización de todas las tablas (Productos y Ventas)
        tablas = ["fact_productos", "audit_productos_rechazados", "fact_ventas_detalle", "audit_ventas_rechazadas"]
        
        for tabla in tablas:
            print(f"📤 Syncing: {tabla}...")
            # Verificamos si la tabla existe en el local antes de intentar subirla
            md_conn.execute(f"CREATE OR REPLACE TABLE ecommerce_cloud.main.{tabla} AS SELECT * FROM local_db.main.{tabla}")

        # Capa Analítica de Negocio
        # Vista 1: Salud de Margen 
        md_conn.execute("""
            CREATE OR REPLACE VIEW ecommerce_cloud.main.v_product_margin_analysis AS
            SELECT proNombre, proPrecio, proCosto, 
                   (proPrecio - proCosto) AS margen_abs,
                   ROUND(((proPrecio - proCosto) / proPrecio) * 100, 2) AS pct_margen
            FROM ecommerce_cloud.main.fact_productos
            ORDER BY pct_margen ASC;
        """)

        # Vista 2: Auditoría de Calidad 
        md_conn.execute("""
            CREATE OR REPLACE VIEW ecommerce_cloud.main.v_data_quality_audit AS
            SELECT 'Productos' as categoria, count(*) as total_errores FROM ecommerce_cloud.main.audit_productos_rechazados
            UNION ALL
            SELECT 'Ventas' as categoria, count(*) as total_errores FROM ecommerce_cloud.main.audit_ventas_rechazadas;
        """)

        # Vista 3: Ventas por Producto 
        md_conn.execute("""
            CREATE OR REPLACE VIEW ecommerce_cloud.main.v_sales_performance AS
            SELECT p.proNombre, SUM(v.unidad) as total_unidades, SUM(v.subtotal) as total_venta
            FROM ecommerce_cloud.main.fact_ventas_detalle v
            JOIN ecommerce_cloud.main.fact_productos p ON v.proCodigo = p.proCodigo
            GROUP BY p.proNombre
            ORDER BY total_venta DESC;
        """)

        md_conn.execute("""CREATE OR REPLACE VIEW ecommerce_cloud.main.v_alerta_operativa_precios AS
            SELECT 
                proNombre, 
                proPrecio, 
                proCosto,
                ROUND(((proPrecio - proCosto) / proPrecio) * 100, 2) AS margen_actual,
                CASE 
                    WHEN proPrecio <= proCosto THEN 'CRÍTICO: MARGEN NEGATIVO'
                    WHEN ((proPrecio - proCosto) / proPrecio) < 0.10 THEN 'ADVERTENCIA: MARGEN BAJO (<10%)'
                    ELSE 'OK'
                END AS estado_operativo
            FROM ecommerce_cloud.main.fact_productos
            WHERE estado_operativo != 'OK';
        """)

    except Exception as e:
        print(f"❌ Error Cloud: {e}")
        print(f"\n")
    finally:
        md_conn.close()