# Importando Librerias y Funciones
import logging
from datetime import datetime
from database_manager import load_sql_to_dataframe, save_to_duckdb_local, get_local_table_names, upload_to_motherduck
from data_quality import run_firewall_products, run_firewall_sales

# Seteando Variables
SQL_SOURCE = 'source.sql'
LOCAL_DB = 'ecommerce_clean.duckdb'
MOTHERDUCK_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImJhdGlzdGF5dXJlaWJhQGdtYWlsLmNvbSIsIm1kUmVnaW9uIjoiYXdzLXVzLWVhc3QtMSIsInNlc3Npb24iOiJiYXRpc3RheXVyZWliYS5nbWFpbC5jb20iLCJwYXQiOiI0Q0ZzNHVJcmZrN2tMZE5CT1M0UnQ3dXhTMnFWRDQ1Q2FSem1wbVZsYTZzIiwidXNlcklkIjoiMzU4YjlkYzEtYmVlNC00ODQ0LWFmOTEtMDk3M2NjNTE4ZTAxIiwiaXNzIjoibWRfcGF0IiwicmVhZE9ubHkiOmZhbHNlLCJ0b2tlblR5cGUiOiJyZWFkX3dyaXRlIiwiaWF0IjoxNzcxMjAyNzc2fQ.ICBtnI-p0ibwId0xxpOOTsx4bJ-1k-xmmZfq3sdj9Ck"

# Configuración del Log
logging.basicConfig(
    filename='pipeline.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

def main():
    # Iniciando Rutina de Verificacion de Calidad de los Datos
    logging.info("--- INICIO DE PROCESO ---")
    print("="*70)
    print("🚀 STARTING DATA INTEGRITY FIREWALL: ELECTRO-MARKET")
    print("="*70 +"\n")

    try:
        logging.info("Iniciando carga de SQL a DataFrame...")
        df_prods = load_sql_to_dataframe(SQL_SOURCE, 'producto')
        df_ventas = load_sql_to_dataframe(SQL_SOURCE, 'venta_detalle')
        logging.info(f"Carga exitosa. Productos: {len(df_prods)}, Ventas: {len(df_ventas)}")

        logging.info("Iniciando validación de calidad (Firewall)...")
        print("▶️  INITIATING DATA VALIDATION.\n")
        p_limpios, p_sucios = run_firewall_products(df_prods)
        v_limpias, v_sucias = run_firewall_sales(df_ventas)
        
        logging.info("Guardando datos en Staging Local (DuckDB)...")
        save_to_duckdb_local(p_limpios, "fact_productos", LOCAL_DB)
        save_to_duckdb_local(p_sucios, "audit_productos_rechazados", LOCAL_DB)
        save_to_duckdb_local(v_limpias, "fact_ventas_detalle", LOCAL_DB)
        save_to_duckdb_local(v_sucias, "audit_ventas_rechazadas", LOCAL_DB)

        print("\n✅ Local Staging Database updated.\n")
        logging.info("Base de datos local DuckDB actualizada correctamente.")

        # Resumen de la verificacion
        print("📊 QUALITY AUDIT RESUME.\n")
        
        # Obtenemos el vector con las tablas desde la función
        tablas_reales = get_local_table_names(LOCAL_DB)

        # Iteramos con el índice para usar tus variables directas
        for i in range(len(tablas_reales)):
            if i == 0:
                print(f"🔍 Total {tablas_reales[i]}: {len(df_prods)} | ❌ Errors Detected: {len(p_sucios)} | ✅ Clean: {len(p_limpios)}.")
            elif i == 1:
                print(f"🔍 Total {tablas_reales[i]}: {len(df_ventas)} | ❌ Errors Detected: {len(v_sucias)} | ✅ Clean: {len(v_limpias)}.")
        
        logging.info(f"Firewall finalizado. Errores Prod: {len(p_sucios)}, Errores Venta: {len(v_sucias)}")
        logging.info(f"Firewall finalizado. Clean Prod: {len(p_limpios)}, Clean Venta: {len(v_limpias)}")
        
        # Desplique en la Nube
        logging.info("Iniciando sincronización con MotherDuck (Cloud)...")
        upload_to_motherduck(LOCAL_DB, MOTHERDUCK_TOKEN)
        logging.info("Sincronización Cloud y creación de vistas analíticas exitosa.")

    except Exception as e:
        logging.error(f"ERROR EN EL PIPELINE: {str(e)}")
        print(f"❌ Error crítico. Revisa pipeline.log")
    
    finally:
        logging.info("--- FIN DE PROCESO ---")
        print("\n" + "="*40)
        print("🎯 PROCESS COMPLETED SUCCESSFULLY.")
        print("📊 ANALYTICS READY IN MOTHERDUCK.")
        print("="*40)

if __name__ == "__main__":
    main()