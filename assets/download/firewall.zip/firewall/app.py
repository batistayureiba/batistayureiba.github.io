import streamlit as st
import duckdb
import plotly.express as px
import pandas as pd

# 1. Configuración de la página
st.set_page_config(page_title="Product Ops Dashboard", layout="wide")

# Token de MotherDuck
MOTHERDUCK_TOKEN = ""

@st.cache_data
def get_data():
    con = duckdb.connect(f"md:?motherduck_token={MOTHERDUCK_TOKEN}")
    con.execute("USE ecommerce_cloud") 
    df_margen = con.execute("SELECT * FROM v_product_margin_analysis").df()
    df_audit = con.execute("SELECT * FROM v_data_quality_audit").df()
    df_sales = con.execute("SELECT * FROM v_sales_performance").df()
    con.close()
    return df_margen, df_audit, df_sales

# Estilo de CSS personalizado para mejorar la tabla
st.markdown("""
    <style>
    .stDataFrame {border: 1px solid #31333F; border-radius: 5px;}
    </style>
    """, unsafe_allow_html=True)

st.title("🚀 Product Operations & Data Integrity Firewall")
st.markdown("---")

try:
    df_m, df_a, df_s = get_data()
    df_m = df_m.round(2)
    df_s = df_s.round(2)

    # --- FILA 1: ALERTAS ---
    productos_alerta = df_m[df_m['pct_margen'] < 10.0]
    if not productos_alerta.empty:
        st.error(f"🚨 **ALERTA OPERATIVA:** {len(productos_alerta)} productos con rentabilidad crítica detectados.")
        with st.expander("Expandir detalles técnicos de SKUs afectados"):
            st.write(", ".join(productos_alerta['proNombre'].tolist()))
    else:
        st.success("✅ **STATUS:** Integridad de márgenes validada. Sin anomalías detectadas.")

    # --- FILA 2: FIREWALL (GRAFICO DE DONA) ---
    st.subheader("🛡️ Data Integrity Firewall Status")
    col1, col2 = st.columns([2, 1])
    
    with col1:
        
        firewall_colors = ['#1E88E5', '#455A64', '#90A4AE', '#112639']
        
        fig_audit = px.pie(df_a, values='total_errores', names='categoria', hole=0.6)
        
        fig_audit.update_traces(
            textposition='outside', 
            textinfo='percent+label',
            textfont=dict(size=18, family="Arial Black", color="#E0E0E0"),
            marker=dict(colors=firewall_colors, line=dict(color='#0E1117', width=3))
        )
        
        fig_audit.update_layout(
            showlegend=False,
            paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)',
            margin=dict(t=30, b=30, l=10, r=10),
            annotations=[dict(text='LOGS<br>Saneados', x=0.5, y=0.5, font_size=20, font_color="#E0E0E0", showarrow=False)]
        )
        st.plotly_chart(fig_audit, use_container_width=True)
        
    with col2:
        st.write("") # Espaciador
        st.write("")
        total_err = df_a['total_errores'].sum()
        st.metric("Registros Bloqueados", f"{total_err}", delta="Calidad 100%")
        st.info("Filtrado preventivo aplicado en la capa de transporte para evitar contaminación del Data Warehouse.")

    # --- FILA 3: TABLA DE MARGENES ---
    st.markdown("---")
    st.subheader("💰 Salud del Portafolio: Análisis de Margen")
    
    def style_margin(v):
        color = '#FF4B4B' if v < 10 else '#00C853'
        return f'color: {color}; font-weight: bold;'

    st.dataframe(
        df_m.style.applymap(style_margin, subset=['pct_margen']),
        use_container_width=True,
        column_config={
            "proPrecio": st.column_config.NumberColumn("Precio Venta ($)", format="%.2f"),
            "proCosto": st.column_config.NumberColumn("Costo Maestro ($)", format="%.2f"),
            "margen_abs": st.column_config.NumberColumn("Margen Neto", format="%.2f"),
            "pct_margen": st.column_config.NumberColumn("Margen %", format="%.2f")
        }
    )

    # --- FILA 4: PERFORMANCE DE VENTAS ---
    st.markdown("---")
    st.subheader("📦 Performance de Ventas (Datos Saneados)")
    
    fig_sales = px.bar(df_s, x='proNombre', y='total_venta', 
                       color='total_venta',
                       color_continuous_scale=['#112639', '#1E88E5'],
                       text_auto='.2s')
    
    fig_sales.update_layout(
        xaxis_title="", 
        yaxis_title="Ventas Totales ($)",
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        font=dict(color="#E0E0E0", size=13),
        margin=dict(t=20),
        showlegend=False
    )
    
    fig_sales.update_traces(
        textposition="outside", 
        textfont=dict(size=13, color="#E0E0E0"),
        marker_line_color='#E0E0E0', 
        marker_line_width=1,
        marker_opacity=0.85
    )
    
    fig_sales.update_coloraxes(showscale=False)
    st.plotly_chart(fig_sales, use_container_width=True)

except Exception as e:
    st.error(f"❌ Error en Pipeline: {e}")

st.markdown("---")
st.caption("Product Ops Infrastructure | MotherDuck Architecture ")