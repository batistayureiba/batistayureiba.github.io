duckdb>=0.9.2          # Motor de base de datos y conexión a MotherDuck             # Crear cuenta
pandas>=2.1.0          # Manipulación de datos y DataFrames

# --- Visualización y Dashboard ---
streamlit>=1.30.0      # Framework del Dashboard interactivo
plotly>=5.18.0         # Gráficos dinámicos de alta calidad

Setear el token de MotherDuck en los archivos
app.py & main.py para la variable MOTHERDUCK_TOKEN

