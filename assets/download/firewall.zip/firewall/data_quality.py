import pandas as pd

def run_firewall_products(df):
    """Filtra productos con margen negativo (proPrecio <= proCosto)."""
    # Basado en tu estructura de productos
    mask_error_precio = df['proPrecio'] <= df['proCosto']
    return df[~mask_error_precio].copy(), df[mask_error_precio].copy()

def run_firewall_sales(df_detalle):
    """Detecta inconsistencias en ventas usando la estructura real del SQL."""
    # Columnas confirmadas por tu ejecución: 
    # ['detVtaCodigo', 'vtaCodigo', 'proCodigo', 'unidad', 'precio_unitario', 'subtotal']
    
    col_cant = 'unidad'
    col_precio = 'precio_unitario'
    col_subtotal = 'subtotal'

    # 1. Calculamos lo que debería ser el subtotal
    df_detalle['subtotal_calculado'] = df_detalle[col_cant] * df_detalle[col_precio]
    
    # 2. Identificamos discrepancias
    mask_error_calculo = (df_detalle[col_subtotal] - df_detalle['subtotal_calculado']).abs() > 0.01
    
    ventas_limpias = df_detalle[~mask_error_calculo].copy()
    ventas_rechazadas = df_detalle[mask_error_calculo].copy()
    
    return ventas_limpias, ventas_rechazadas